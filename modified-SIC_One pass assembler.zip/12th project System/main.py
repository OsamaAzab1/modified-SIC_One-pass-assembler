#InstructionSetDefinition
import math
import sys
Format3 = {
        "ADD":int("18",16),
        "AND":int("40",16),
        "COMP":int("28",16),
        "DIV":int("24",16),
        "J":int("3C",16),
        "JEQ":int("30",16),
        "JGT":int("34",16),
        "JLT":int("38",16),
        "JSUB":int("48",16),
        "LDA":int("00",16),
        "LDCH":int("50",16),
        "LDL":int("08",16),
        "LDX":int("04",16),
        "MUL":int("20",16),
        "OR":int("44",16),
        "RD":int("D8",16),
        "RSUB":int("4C",16),
        "STA":int("0C",16),
        "STCH":int("54",16),
        "STL":int("14",16),
        "STSW":int("E8",16),
        "STX":int("10",16),
        "SUB":int("1C",16),
        "TD":int("E0",16),
        "TIX":int("2C",16),
        "WD":int("DC",16)
        }
Format1 = {
        "FIX":int("C4",16),
        "FLOAT":int("C0",16),
        "HIO":int("F4",16),
        "NORM":int("C8",16),
        "SIO":int("F0",16),
        "TIO":int("F8",16),
        }
OtherInstructions = {
        "WORD",
        "RESW",
        "BYTE",
        "RESB",
        "END",
        "START",

        }
def main():
    with open("input.txt") as f:
        labels = []
        input_instructions = []
        input_arguments = []
        for line in f:
            x = line.split()
            x = " ".join(x)
            x = x.upper()
            x = x.split()
            if (x[0] in Format3 or x[0] in Format1 or x[0] in OtherInstructions):
                labels.append("")
                input_instructions.append(x[0])
                if (x[0] == "RSUB" or x[0] == "END" or x[0] in Format1):
                    input_arguments.append("")
                else:
                    input_arguments.append(x[1])
            elif (x[1] in Format3 or x[1] in Format1 or x[1] in OtherInstructions):
                labels.append(x[0])
                input_instructions.append(x[1])
                if (x[1] == "RSUB" or x[1] in Format1):
                    input_arguments.append("")
                else:
                    input_arguments.append(x[2])

        #pass1
        Current_Location = int(input_arguments[0], 16)

        Location_Counter = [''] * len(input_instructions)
        Program_Name = labels[0]
        if (len(Program_Name) > 6):
            print(" Syntax Error Program Name is too long")
        for i in range(1, len(input_instructions)):
            if (input_instructions[i] == "END"):
                Location_Counter[i] = hex(Current_Location)
                continue
            if input_instructions[i] in Format3 or input_instructions[i] == "WORD":
                Location_Counter[i] = hex(Current_Location)
                Current_Location += 3
            elif input_instructions[i] in Format1 or input_instructions[i] == "BYTE":
                Location_Counter[i] = hex(Current_Location)
                if (input_instructions[i] == "BYTE"):
                    if input_arguments[i][0] == 'C':
                        Current_Location += len(input_arguments[i]) - 3
                    elif input_arguments[i][0] == 'X':
                        Current_Location += math.floor((len(input_arguments[i]) - 3) / 2)
                else:
                    Current_Location += 1
            elif input_instructions[i] in OtherInstructions:
                Location_Counter[i] = hex(Current_Location)
                if input_instructions[i] == "RESW":
                    Current_Location += int(input_arguments[i]) * 3
                elif input_instructions[i] == "RESB":
                    Current_Location += int(input_arguments[i])
            else:
                Location_Counter[i] = ""
        Symbol_Table = {}
        Unkown_location_arg={}
        obcode = []
        prev_labels=[]
        obcode.append("")







        for i in range(1, len(input_instructions)):
            if input_instructions[i]=="RESW" or input_instructions[i]=="RESB" and labels[i]!='':
                Symbol_Table[labels[i]] = Location_Counter[i][2:]
                obcode.append("")
            elif (labels[i] != ''):
                Symbol_Table[labels[i]] = Location_Counter[i][2:]

                pass2(input_instructions[i], input_arguments[i], Format3, Format1, OtherInstructions, Symbol_Table, Location_Counter[i], labels[:i],obcode,Unkown_location_arg)
            elif (labels[i]==''):
                pass2(input_instructions[i], input_arguments[i], Format3, Format1, OtherInstructions, Symbol_Table,Location_Counter[i], labels[:i], obcode,Unkown_location_arg)

        if obcode:
            obcode.pop()
        obcode[-1]=""
        with open("out_pass1.txt", "w") as f:
            for i in range(len(input_instructions)):
                f.write(Location_Counter[i][2:].ljust(6) + "    " + labels[i].ljust(6) + "    " + input_instructions[
                    i].ljust(6) + "    " + input_arguments[i].ljust(6) + "\n")
        with open("symbTable.txt", "w") as f:
            for symbol in Symbol_Table:
                f.write(symbol.ljust(20) + "    " + Symbol_Table[symbol] + "\n")
        with open("out_pass2.txt", "w") as f:
            for i in range(len(input_instructions)):
                f.write(Location_Counter[i][2:].ljust(6) + "    " + labels[i].ljust(6) + "    " + input_instructions[i].ljust(6) + "    " + input_arguments[i].ljust(6) + "       " + obcode[i].ljust(6) + "\n")
        with open("HTE.txt", "w") as f:
            records = []

            while len(Program_Name) < 6:
                Program_Name = Program_Name + "X"

            Starting_Address = Location_Counter[1][2:]
            while len(Starting_Address) < 6:
                Starting_Address = "0" + Starting_Address

            Ending_Address = Location_Counter[len(Location_Counter) - 1][2:]
            Program_Size = int(Ending_Address, 16) - int(Starting_Address, 16)
            Program_Size = hex(Program_Size)[2:]
            while len(Program_Size) < 6:
                Program_Size = "0" + Program_Size

            records.append(f"H{Program_Name.ljust(6)}{Starting_Address.ljust(6)}{Program_Size}")

            i = 1
            while i < len(input_instructions):
                T_Starting_Address = int(Location_Counter[i][2:], 16)
                T_Record = ""
                T_Record_Size = 0
                masking_bits = ""
                unknown = []
                flag = 0


                while T_Record_Size < 30:
                    if i == len(input_instructions):
                        break
                    if obcode[i] == '':
                        i += 1
                        break

                    if T_Record_Size + math.floor(len(obcode[i]) / 2) <= 30:
                        if input_instructions[i] in Format3 and not input_arguments[i].startswith("#") and input_instructions[i] != "RSUB" and not input_arguments[i].startswith(" "):
                            masking_bits += "1"
                        else:
                            masking_bits += "0"
                        T_Record_Size += math.floor(len(obcode[i]) / 2)
                        T_Record += obcode[i]



                        if i + 1 < len(labels) and labels[i + 1] in Unkown_location_arg:
                            flag=1
                            masking_bitsun = "000"
                            rec_size = "02"
                            j = 0
                            multiple=0
                            while labels[i + 1] in Unkown_location_arg and j < len(Unkown_location_arg[labels[i + 1]]):
                                srt_add = Unkown_location_arg[labels[i + 1]][j]
                                real_add = Symbol_Table[labels[i + 1]]
                                unknown.append(f"T{'00'+srt_add.ljust(6)}{rec_size.ljust(3)}{masking_bitsun.ljust(4)}{real_add.ljust(6)}")




                                #records.append(f"T{srt_add.ljust(6)}{rec_size.ljust(3)}{masking_bitsun.ljust(4)}{real_add.ljust(6)}")
                                j += 1


                            if (j>1):
                                unknown1=[]
                                multiple=1
                                for k in range(len(unknown)):
                                    unknown1.append(unknown[k])

                            i += 1
                            break
                        i += 1
                    elif T_Record_Size + math.floor(len(obcode[i]) / 2) > 30:
                        break
                if(flag==0):
                    if (T_Record_Size == 0):
                        continue
                    T_Record_Size = hex(T_Record_Size)[2:]

                    while (len(T_Record_Size) < 2):
                        T_Record_Size = "0" + T_Record_Size
                    T_Starting_Address = hex(T_Starting_Address)[2:]
                    while (len(T_Starting_Address) < 6):
                        T_Starting_Address = "0" + T_Starting_Address
                    while (len(masking_bits) < 12):
                        masking_bits += "0"
                    masking_bits_hex = hex(int(masking_bits, 2))[2:]

                    if (len(masking_bits_hex) == 1):
                        masking_bits_hex = '00' + masking_bits_hex


                    records.append(
                        "T" + T_Starting_Address + T_Record_Size.upper() + masking_bits_hex.upper() + T_Record)

                if(flag==1):
                    if (T_Record_Size == 0):
                        continue
                    T_Record_Size = hex(T_Record_Size)[2:]

                    while (len(T_Record_Size) < 2):
                        T_Record_Size = "0" + T_Record_Size
                    T_Starting_Address = hex(T_Starting_Address)[2:]
                    while (len(T_Starting_Address) < 6):
                        T_Starting_Address = "0" + T_Starting_Address
                    while (len(masking_bits) < 12):
                        masking_bits += "0"
                    masking_bits_hex = hex(int(masking_bits, 2))[2:]




                    records.append("T" + T_Starting_Address + T_Record_Size.upper() + masking_bits_hex.upper() + T_Record)
                    if multiple==0:
                        records.append(unknown[0])


                    if multiple ==1:
                        for k in range(len(unknown1)):
                            records.append(unknown1[k])
                    #if multiple ==1:
                        #records.append(unknown1)



            records.append(f"E{'00'+Location_Counter[-1][2:]}")
            for record in records:
                f.write(record + "\n")







        print(input_instructions)
        print(input_arguments)
        print(obcode)
        print(Unkown_location_arg)
        print(labels)

def pass2(input_instructions, input_arguments, Format3, Format1, OtherInstructions, Symbol_Table, Location_Counter, labels, obcode, Unkown_location_arg):
    ob_code = ''

    if input_instructions in OtherInstructions:
        input_arguments_hex = ""
        if input_instructions == "WORD":
            input_arguments_hex = hex(int(input_arguments))[2:]
            while len(input_arguments_hex) < 6:
                input_arguments_hex = "0" + input_arguments_hex
        elif input_instructions == "BYTE":
            if input_arguments[0] == "C":
                real_input_argument = input_arguments
                real_input = real_input_argument[2:-1]
                hexa = ""
                for j in range(len(real_input)):
                    in1 = ord(real_input[j])
                    part = hex(in1).lstrip("0x")
                    hexa += part
                input_arguments_hex += hexa
            elif input_arguments[0] == "X":
                real_input_argument = input_arguments
                input_arguments_hex = real_input_argument[2:-1]

        ob_code = input_arguments_hex
    elif input_instructions in Format3:
        address = ""
        address_hex = 0
        if input_instructions == "RSUB":
            op_code = Format3[input_instructions]
            op_code_str = hex(op_code)[2:]
            address = hex(address_hex)[2:]
            while len(op_code_str) < 2:
                op_code_str = "0" + op_code_str
            while len(address) < 4:
                address = "0" + address
            ob_code = op_code_str + address
            obcode.append(ob_code)

        currentargumentwithcomma = input_arguments.split(",")
        currentargument = currentargumentwithcomma[0]
        op_code = Format3[input_instructions]



        if currentargument and currentargument[0] == "#":


            op_code+=1


            if currentargument[1:] in Symbol_Table:
                address_hex = int(Symbol_Table[currentargument[1:]], 16)

            else:
                address_hex = int(currentargument[1:], 10)

        elif currentargument in Symbol_Table:
            address_hex = int(Symbol_Table[currentargument], 16)



        if currentargument  not in labels and currentargument[0] !="#":
            Location = hex(int(Location_Counter, 16) + 1)[2:]
            op_code = Format3[input_instructions]
            address = hex(address_hex)[2:]
            address = "000" + address
            op_code_str = hex(op_code)[2:]
            ob_code = op_code_str + address
            if currentargument not in Unkown_location_arg and currentargument[0] !="#":
                Unkown_location_arg[currentargument] = [Location]
            elif currentargument in Unkown_location_arg and currentargument[0] !="#":
                Unkown_location_arg[currentargument].append(Location)


        if len(currentargumentwithcomma) > 1:
            if currentargumentwithcomma[1] == "X":
                address_hex = address_hex + 32768



        op_code_str = hex(op_code)[2:]


        address = hex(address_hex)[2:]

        while len(op_code_str) < 2:
            op_code_str = "0" + op_code_str
        while len(address) < 4:
            address = "0" + address
        ob_code = op_code_str + address
        print(ob_code)

    if input_instructions in Format1:
        op_code = Format1[input_instructions]
        op_code_str = hex(op_code)[2:]
        while len(op_code_str) < 2:
            op_code_str = "0" + op_code_str
        ob_code = op_code_str
    obcode.append(ob_code)








if __name__ == '__main__':
    main()
